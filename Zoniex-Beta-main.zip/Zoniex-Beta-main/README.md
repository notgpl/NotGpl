![Zoniex Inc](https://i.imgur.com/70rL1Px.png)
<p align="center">
  <a href="https://discord.gg/tjX8fVa7b3"><img src="https://img.shields.io/discord/1264480934212927508?color=blue&label=Discord&logo=HolaClient&logoColor=blue" alt="discord" /></a>
  <a href="https://zoniex.me"><img alt="Website" src="https://img.shields.io/website?down_color=lightred&down_message=Offline&label=Website&up_color=blue&up_message=Online&url=https://zoniex.me"></a>
  <a  href="https://github.com/Zoniex-Inc/Zoniex-Beta"><img src="https://img.shields.io/github/stars/Zoniex-Inc/Zoniex-Beta?label=Stars%20%E2%AD%90" height="20"/></a>
  <img src="https://komarev.com/ghpvc/?username=PatentGuyy&color=blue">
</p>

---

<h1 align="center">Zoniex</h1>

Zoniex is a development company offering reliable hosting services and a feature-rich Discord bot. We provide premium, paid services tailored to your needs, from web development to automation solutions. At Zoniex, we focus on delivering quality and innovation.

---

<br>
<p align="center">Copyright © 2023 - 2024 PatentGuy</p>
